<?php
// Membuat koneksi ke database
$host = "localhost";
$user = "root";
$password = "";
$database = "db_uas";

//printah php untuk akses ke database
$koneksi = mysqli_connect($host, $user, $password, $database);

?>